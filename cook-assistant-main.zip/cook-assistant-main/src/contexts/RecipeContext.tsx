import React, { createContext, useContext, useState, useEffect } from "react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { doc, setDoc, getDoc, collection, query, where, getDocs, addDoc, deleteDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";

export type Recipe = {
  idMeal: string;
  strMeal: string;
  strCategory: string;
  strArea: string;
  strInstructions: string;
  strMealThumb: string;
  strTags: string;
  strYoutube: string;
  ingredients: { name: string; measure: string }[];
  matchedIngredients?: number;
  missingIngredients?: number;
  nutrition?: {
    fiber?: number;
    protein?: number;
    carbs?: number;
  };
};

export type RecipeCategory = {
  idCategory: string;
  strCategory: string;
  strCategoryThumb: string;
  strCategoryDescription: string;
};

export type RecipeArea = {
  strArea: string;
};

interface RecipeContextType {
  recipes: Recipe[];
  popularRecipes: Recipe[];
  recentlyViewed: Recipe[];
  favorites: Recipe[];
  isLoading: boolean;
  searchRecipes: (
    ingredients: string[], 
    filters?: { 
      areas?: string[], 
      categories?: string[],
      nutrition?: {
        fiber?: boolean,
        protein?: boolean,
        carbs?: boolean
      }
    }
  ) => Promise<void>;
  getRecipeDetails: (id: string) => Promise<Recipe | undefined>;
  addToFavorites: (recipe: Recipe) => void;
  removeFromFavorites: (id: string) => void;
  addToRecentlyViewed: (recipe: Recipe) => void;
  getRandomRecipes: (count?: number) => Promise<Recipe[]>;
  getAreas: () => Promise<RecipeArea[]>;
  getCategories: () => Promise<RecipeCategory[]>;
  searchByPreference: (preference: string) => Promise<Recipe[]>;
}

const RecipeContext = createContext<RecipeContextType | undefined>(undefined);

export const RecipeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [popularRecipes, setPopularRecipes] = useState<Recipe[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<Recipe[]>([]);
  const [favorites, setFavorites] = useState<Recipe[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const loadUserData = async () => {
      if (!user) {
        const storedFavorites = localStorage.getItem("cookeryFavorites");
        if (storedFavorites) {
          setFavorites(JSON.parse(storedFavorites));
        } else {
          setFavorites([]);
        }
        
        const storedRecentlyViewed = localStorage.getItem("cookeryRecentlyViewed");
        if (storedRecentlyViewed) {
          setRecentlyViewed(JSON.parse(storedRecentlyViewed));
        } else {
          setRecentlyViewed([]);
        }
        return;
      }
      
      try {
        const favoritesQuery = query(collection(db, "favorites"), where("userId", "==", user.id));
        const favoritesSnapshot = await getDocs(favoritesQuery);
        const favoritesData: Recipe[] = [];
        
        favoritesSnapshot.forEach(doc => {
          const data = doc.data();
          if (data.recipe) {
            favoritesData.push(data.recipe as Recipe);
          }
        });
        
        setFavorites(favoritesData);
        
        const historyQuery = query(
          collection(db, "history"), 
          where("userId", "==", user.id)
        );
        const historySnapshot = await getDocs(historyQuery);
        const historyData: Recipe[] = [];
        
        historySnapshot.forEach(doc => {
          const data = doc.data();
          if (data.recipe) {
            historyData.push(data.recipe as Recipe);
          }
        });
        
        historyData.sort((a: any, b: any) => {
          if (a.timestamp && b.timestamp) {
            return b.timestamp - a.timestamp;
          }
          return 0;
        });
        
        setRecentlyViewed(historyData.slice(0, 10));
      } catch (error) {
        console.error("Error loading user data:", error);
        toast.error("Failed to load your saved recipes");
      }
    };
    
    loadUserData();
  }, [user]);

  useEffect(() => {
    getRandomRecipes(8).then(recipes => {
      setPopularRecipes(recipes);
    });
  }, []);

  const formatRecipe = (meal: any): Recipe => {
    const ingredients = [];
    for (let i = 1; i <= 20; i++) {
      if (meal[`strIngredient${i}`] && meal[`strIngredient${i}`].trim()) {
        ingredients.push({
          name: meal[`strIngredient${i}`],
          measure: meal[`strMeasure${i}`] || ""
        });
      }
    }
    
    return {
      idMeal: meal.idMeal,
      strMeal: meal.strMeal,
      strCategory: meal.strCategory,
      strArea: meal.strArea,
      strInstructions: meal.strInstructions,
      strMealThumb: meal.strMealThumb,
      strTags: meal.strTags,
      strYoutube: meal.strYoutube,
      ingredients
    };
  };

  const searchRecipes = async (
    ingredients: string[], 
    filters?: { 
      areas?: string[], 
      categories?: string[],
      nutrition?: {
        fiber?: boolean,
        protein?: boolean,
        carbs?: boolean
      }
    }
  ) => {
    setIsLoading(true);
    try {
      const searchResults: Recipe[] = [];
      
      for (const ingredient of ingredients) {
        const response = await fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${ingredient}`);
        const data = await response.json();
        
        if (data.meals) {
          for (const meal of data.meals) {
            const detailsResponse = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`);
            const detailsData = await detailsResponse.json();
            
            if (detailsData.meals && detailsData.meals[0]) {
              const recipe = formatRecipe(detailsData.meals[0]);
              
              if (filters) {
                if (filters.areas && filters.areas.length > 0 && !filters.areas.includes(recipe.strArea)) {
                  continue;
                }
                if (filters.categories && filters.categories.length > 0 && !filters.categories.includes(recipe.strCategory)) {
                  continue;
                }
                
                const ingredientsList = recipe.ingredients.map(i => i.name.toLowerCase()).join(' ');
                
                if (filters.nutrition) {
                  if (filters.nutrition.fiber && !ingredientsList.match(/fiber|fibre|bran|whole grain|beans|legumes|vegetables/i)) {
                    continue;
                  }
                  
                  if (filters.nutrition.protein && !ingredientsList.match(/protein|meat|chicken|fish|egg|eggs|beans|tofu|cheese|milk|yogurt/i)) {
                    continue;
                  }
                  
                  if (filters.nutrition.carbs && !ingredientsList.match(/carbs|carbohydrates|pasta|rice|bread|potato|grain|flour/i)) {
                    continue;
                  }
                }
              }
              
              const recipeIngredients = recipe.ingredients.map(i => i.name.toLowerCase());
              const matchedIngredients = ingredients.filter(i => 
                recipeIngredients.some(ri => ri.includes(i.toLowerCase()))
              ).length;
              
              recipe.matchedIngredients = matchedIngredients;
              recipe.missingIngredients = recipeIngredients.length - matchedIngredients;
              
              if (!searchResults.some(r => r.idMeal === recipe.idMeal)) {
                searchResults.push(recipe);
              }
            }
          }
        }
      }
      
      searchResults.sort((a, b) => {
        if (b.matchedIngredients === a.matchedIngredients) {
          return (a.missingIngredients || 0) - (b.missingIngredients || 0);
        }
        return (b.matchedIngredients || 0) - (a.matchedIngredients || 0);
      });
      
      setRecipes(searchResults);
      
      if (searchResults.length === 0) {
        toast.info("No recipes found with these ingredients. Try different ingredients.");
      } else {
        toast.success(`Found ${searchResults.length} recipes`);
      }
    } catch (error) {
      console.error("Error searching recipes:", error);
      toast.error("Failed to search recipes. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const getRecipeDetails = async (id: string): Promise<Recipe | undefined> => {
    try {
      const response = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`);
      const data = await response.json();
      
      if (data.meals && data.meals[0]) {
        return formatRecipe(data.meals[0]);
      }
      return undefined;
    } catch (error) {
      console.error("Error fetching recipe details:", error);
      toast.error("Failed to load recipe details. Please try again.");
      return undefined;
    }
  };

  const addToFavorites = async (recipe: Recipe) => {
    if (!favorites.some(fav => fav.idMeal === recipe.idMeal)) {
      try {
        const updatedFavorites = [...favorites, recipe];
        setFavorites(updatedFavorites);
        
        if (user) {
          await addDoc(collection(db, "favorites"), {
            userId: user.id,
            recipeId: recipe.idMeal,
            recipe: recipe,
            timestamp: new Date().getTime()
          });
        } else {
          localStorage.setItem("cookeryFavorites", JSON.stringify(updatedFavorites));
        }
        
        toast.success(`Added ${recipe.strMeal} to favorites`);
      } catch (error) {
        console.error("Error adding to favorites:", error);
        toast.error("Failed to add to favorites");
      }
    }
  };

  const removeFromFavorites = async (id: string) => {
    const recipe = favorites.find(fav => fav.idMeal === id);
    if (recipe) {
      try {
        const updatedFavorites = favorites.filter(fav => fav.idMeal !== id);
        setFavorites(updatedFavorites);
        
        if (user) {
          const favoritesQuery = query(
            collection(db, "favorites"), 
            where("userId", "==", user.id),
            where("recipeId", "==", id)
          );
          
          const querySnapshot = await getDocs(favoritesQuery);
          
          if (!querySnapshot.empty) {
            querySnapshot.forEach(async (doc) => {
              await deleteDoc(doc.ref);
            });
          } else {
            localStorage.setItem("cookeryFavorites", JSON.stringify(updatedFavorites));
          }
        } else {
          localStorage.setItem("cookeryFavorites", JSON.stringify(updatedFavorites));
        }
        
        toast.success(`Removed ${recipe.strMeal} from favorites`);
      } catch (error) {
        console.error("Error removing from favorites:", error);
        toast.error("Failed to remove from favorites");
      }
    }
  };

  const addToRecentlyViewed = async (recipe: Recipe) => {
    try {
      const filteredList = recentlyViewed.filter(r => r.idMeal !== recipe.idMeal);
      const updatedRecentlyViewed = [recipe, ...filteredList.slice(0, 9)];
      
      setRecentlyViewed(updatedRecentlyViewed);
      
      if (user) {
        const historyQuery = query(
          collection(db, "history"), 
          where("userId", "==", user.id),
          where("recipeId", "==", recipe.idMeal)
        );
        
        const querySnapshot = await getDocs(historyQuery);
        
        if (!querySnapshot.empty) {
          querySnapshot.forEach(async (doc) => {
            await setDoc(doc.ref, {
              userId: user.id,
              recipeId: recipe.idMeal,
              recipe: recipe,
              timestamp: new Date().getTime()
            });
          });
        } else {
          await addDoc(collection(db, "history"), {
            userId: user.id,
            recipeId: recipe.idMeal,
            recipe: recipe,
            timestamp: new Date().getTime()
          });
        }
      } else {
        localStorage.setItem("cookeryRecentlyViewed", JSON.stringify(updatedRecentlyViewed));
      }
    } catch (error) {
      console.error("Error adding to recently viewed:", error);
    }
  };

  const getRandomRecipes = async (count = 10): Promise<Recipe[]> => {
    const randomRecipes: Recipe[] = [];
    try {
      for (let i = 0; i < count; i++) {
        const response = await fetch("https://www.themealdb.com/api/json/v1/1/random.php");
        const data = await response.json();
        
        if (data.meals && data.meals[0]) {
          const recipe = formatRecipe(data.meals[0]);
          
          if (!randomRecipes.some(r => r.idMeal === recipe.idMeal)) {
            randomRecipes.push(recipe);
          } else {
            i--;
          }
        }
      }
      return randomRecipes;
    } catch (error) {
      console.error("Error fetching random recipes:", error);
      toast.error("Failed to load random recipes. Please try again.");
      return [];
    }
  };

  const getAreas = async (): Promise<RecipeArea[]> => {
    try {
      const response = await fetch("https://www.themealdb.com/api/json/v1/1/list.php?a=list");
      const data = await response.json();
      
      return data.meals || [];
    } catch (error) {
      console.error("Error fetching areas:", error);
      toast.error("Failed to load cuisine types. Please try again.");
      return [];
    }
  };

  const getCategories = async (): Promise<RecipeCategory[]> => {
    try {
      const response = await fetch("https://www.themealdb.com/api/json/v1/1/categories.php");
      const data = await response.json();
      
      return data.categories || [];
    } catch (error) {
      console.error("Error fetching categories:", error);
      toast.error("Failed to load recipe categories. Please try again.");
      return [];
    }
  };

  const searchByPreference = async (preference: string): Promise<Recipe[]> => {
    try {
      const response = await fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?a=${preference}`);
      const data = await response.json();
      
      if (data.meals) {
        const detailedRecipes: Recipe[] = [];
        
        for (const meal of data.meals.slice(0, 8)) {
          const detailsResponse = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`);
          const detailsData = await detailsResponse.json();
          
          if (detailsData.meals && detailsData.meals[0]) {
            detailedRecipes.push(formatRecipe(detailsData.meals[0]));
          }
        }
        
        return detailedRecipes;
      }
      return [];
    } catch (error) {
      console.error(`Error fetching ${preference} recipes:`, error);
      toast.error(`Failed to load ${preference} recipes. Please try again.`);
      return [];
    }
  };

  return (
    <RecipeContext.Provider value={{
      recipes,
      popularRecipes,
      recentlyViewed,
      favorites,
      isLoading,
      searchRecipes,
      getRecipeDetails,
      addToFavorites,
      removeFromFavorites,
      addToRecentlyViewed,
      getRandomRecipes,
      getAreas,
      getCategories,
      searchByPreference
    }}>
      {children}
    </RecipeContext.Provider>
  );
};

export const useRecipes = () => {
  const context = useContext(RecipeContext);
  if (context === undefined) {
    throw new Error("useRecipes must be used within a RecipeProvider");
  }
  return context;
};
