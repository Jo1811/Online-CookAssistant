
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAHSLEDZy1QL9sTE9__FUQb4Q5-t911ihM",
  authDomain: "backend-cook.firebaseapp.com",
  projectId: "backend-cook",
  storageBucket: "backend-cook.firebasestorage.app",
  messagingSenderId: "741630458134",
  appId: "1:741630458134:web:04c741a2b27129f9863837",
  measurementId: "G-M7QLKTJ3ME"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };


// Ensure auth is exported
//export const auth = getAuth(app);
