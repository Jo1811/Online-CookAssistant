
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

const AuthPage = () => {
  const navigate = useNavigate();
  const { login, signup, isLoading } = useAuth();
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    username: ""
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const toggleMode = () => {
    setIsLoginMode(!isLoginMode);
    setErrors({});
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    
    // Clear error when user types
    if (errors[name]) {
      setErrors({ ...errors, [name]: "" });
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.email) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid";
    }
    
    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }
    
    if (!isLoginMode && !formData.username) {
      newErrors.username = "Username is required";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) return;
    
    try {
      if (isLoginMode) {
        await login(formData.email, formData.password);
      } else {
        await signup(formData.email, formData.username, formData.password);
      }
      navigate("/");
    } catch (error) {
      console.error("Auth error:", error);
    }
  };

  const goBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative py-12">
      <div className="absolute inset-0 bg-food-pattern bg-cover bg-center opacity-10"></div>
      
      <button
        onClick={goBack}
        className="absolute top-6 left-6 p-2 rounded-full bg-white/80 hover:bg-white shadow-md transition-colors"
      >
        <ArrowLeft className="h-5 w-5 text-gray-700" />
      </button>
      
      <div className="w-full max-w-md z-10">
        <div className="glassmorphism rounded-2xl p-8 shadow-lg">
          <div className="text-center mb-6">
            <img src="/lovable-uploads/fbb3f56d-2e3a-40bd-be5d-c3f89995de4d.png" alt="Cooking Assistant" className="h-20 w-20 mx-auto mb-4" />
            <h1 className="text-2xl font-bold">{isLoginMode ? "Welcome Back" : "Create Account"}</h1>
            <p className="text-gray-600 mt-2">
              {isLoginMode 
                ? "Sign in to access your favorite recipes" 
                : "Join Cooking Assistant to discover amazing recipes"}
            </p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLoginMode && (
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  value={formData.username}
                  onChange={handleChange}
                  className={cn(errors.username && "border-red-300")}
                  placeholder="Enter your username"
                />
                {errors.username && (
                  <p className="text-sm text-red-500">{errors.username}</p>
                )}
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                className={cn(errors.email && "border-red-300")}
                placeholder="Enter your email"
              />
              {errors.email && (
                <p className="text-sm text-red-500">{errors.email}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={formData.password}
                onChange={handleChange}
                className={cn(errors.password && "border-red-300")}
                placeholder="Enter your password"
              />
              {errors.password && (
                <p className="text-sm text-red-500">{errors.password}</p>
              )}
            </div>
            
            <Button
              type="submit"
              className="w-full bg-cook-primary hover:bg-cook-primary/90 text-white mt-6"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {isLoginMode ? "Signing in..." : "Creating account..."}
                </>
              ) : (
                isLoginMode ? "Sign In" : "Create Account"
              )}
            </Button>
          </form>
          
          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={toggleMode}
              className="text-cook-secondary hover:text-cook-secondary/80 text-sm"
            >
              {isLoginMode 
                ? "Don't have an account? Sign up" 
                : "Already have an account? Sign in"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
