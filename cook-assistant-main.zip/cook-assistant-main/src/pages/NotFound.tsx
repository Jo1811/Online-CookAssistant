
import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChefHat, Home } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center max-w-md px-4 glassmorphism rounded-xl p-8">
        <div className="w-24 h-24 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <ChefHat className="h-12 w-12 text-cook-primary" />
        </div>
        <h1 className="text-5xl font-bold mb-4 text-cook-dark">404</h1>
        <p className="text-xl text-gray-600 mb-8">Oops! We couldn't find that recipe.</p>
        <div className="space-y-3">
          <p className="text-gray-500 mb-6">
            The page you're looking for might have been removed, had its name changed, or is temporarily unavailable.
          </p>
          <Link to="/">
            <Button className="bg-cook-primary hover:bg-cook-primary/90 text-white">
              <Home className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
