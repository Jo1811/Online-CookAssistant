
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useRecipes } from "@/contexts/RecipeContext";
import { useAuth } from "@/contexts/AuthContext";
import { RecipeArea, RecipeCategory } from "@/contexts/RecipeContext";
import HeroSection from "@/components/home/HeroSection";
import RecipeSection from "@/components/home/RecipeSection";

const HomePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { 
    popularRecipes, 
    searchRecipes, 
    searchByPreference, 
    getAreas,
    getCategories,
  } = useRecipes();
  
  const [areas, setAreas] = useState<RecipeArea[]>([]);
  const [categories, setCategories] = useState<RecipeCategory[]>([]);
  const [filters, setFilters] = useState<{ areas: string[]; categories: string[] }>({
    areas: [],
    categories: [],
  });
  const [preferenceRecipes, setPreferenceRecipes] = useState<{ [key: string]: any[] }>({});

  useEffect(() => {
    // Load filter options
    getAreas().then(setAreas);
    getCategories().then(setCategories);
    
    // If user is logged in and has preferences, load preference-based recipes
    if (user?.preferences && user.preferences.length > 0) {
      const loadPreferences = async () => {
        const preferencesData: { [key: string]: any[] } = {};
        
        for (const preference of user.preferences) {
          const recipes = await searchByPreference(preference);
          if (recipes.length > 0) {
            preferencesData[preference] = recipes;
          }
        }
        
        setPreferenceRecipes(preferencesData);
      };
      
      loadPreferences();
    }
  }, [user]);

  const handleSearch = (ingredients: string[]) => {
    searchRecipes(ingredients, filters);
    navigate("/search-results");
  };

  const handleFilterChange = (newFilters: { areas: string[]; categories: string[] }) => {
    setFilters(newFilters);
  };

  return (
    <div className="min-h-screen">
      <HeroSection 
        onSearch={handleSearch}
        onFilterChange={handleFilterChange}
        areas={areas}
        categories={categories}
      />
      
      <RecipeSection 
        popularRecipes={popularRecipes}
        preferenceRecipes={preferenceRecipes}
      />
    </div>
  );
};

export default HomePage;
