
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useRecipes } from "@/contexts/RecipeContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import RecipeCard from "@/components/RecipeCard";
import PreferenceSelector from "@/components/PreferenceSelector";
import { ArrowLeft, Loader2, Save } from "lucide-react";
import { RecipeArea } from "@/contexts/RecipeContext";

const ProfilePage = () => {
  const navigate = useNavigate();
  const { user, updateUserPreferences, isLoading: authLoading } = useAuth();
  const { recentlyViewed, getAreas } = useRecipes();
  
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [cuisines, setCuisines] = useState<string[]>([]);
  const [selectedPreferences, setSelectedPreferences] = useState<string[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  
  useEffect(() => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    setUsername(user.username);
    setEmail(user.email);
    setSelectedPreferences(user.preferences || []);
    
    // Load available cuisines
    getAreas().then((areas: RecipeArea[]) => {
      const cuisinesList = areas.map(area => area.strArea);
      setCuisines(cuisinesList);
    });
  }, [user]);

  const handleSaveProfile = async () => {
    if (!user) return;
    
    setIsSaving(true);
    try {
      await updateUserPreferences(selectedPreferences);
      setIsSaving(false);
    } catch (error) {
      console.error("Error saving profile:", error);
      setIsSaving(false);
    }
  };

  const goBack = () => {
    navigate(-1);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <Loader2 className="h-8 w-8 text-cook-primary animate-spin" />
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect to auth in useEffect
  }

  return (
    <div className="min-h-screen py-6">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={goBack}
            className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-2xl font-bold">Your Profile</h1>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Profile Info */}
          <div className="lg:col-span-1">
            <div className="glassmorphism rounded-xl p-6 shadow-lg">
              <h2 className="text-xl font-semibold mb-4">Account Information</h2>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled
                    className="bg-gray-50"
                  />
                  <p className="text-xs text-gray-500">Username cannot be changed</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled
                    className="bg-gray-50"
                  />
                  <p className="text-xs text-gray-500">Email cannot be changed</p>
                </div>
                
                <div className="pt-4">
                  <PreferenceSelector
                    preferences={cuisines}
                    selectedPreferences={selectedPreferences}
                    onChange={setSelectedPreferences}
                  />
                </div>
                
                <Button
                  onClick={handleSaveProfile}
                  className="w-full mt-6 bg-cook-primary hover:bg-cook-primary/90"
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Preferences
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
          
          {/* Right Column - Recently Viewed */}
          <div className="lg:col-span-2">
            <div className="glassmorphism rounded-xl p-6 shadow-lg">
              <h2 className="text-xl font-semibold mb-4">Recently Viewed Recipes</h2>
              
              {recentlyViewed.length === 0 ? (
                <p className="text-gray-500 py-8 text-center">
                  You haven't viewed any recipes yet. Start exploring!
                </p>
              ) : (
                <div className="space-y-3">
                  {recentlyViewed.map((recipe) => (
                    <RecipeCard
                      key={recipe.idMeal}
                      recipe={recipe}
                      variant="compact"
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
