import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useRecipes } from "@/contexts/RecipeContext";
import { RecipeArea, RecipeCategory } from "@/contexts/RecipeContext";
import SearchHeader from "@/components/search/SearchHeader";
import RecipeResults from "@/components/search/RecipeResults";

const SearchResultsPage = () => {
  const navigate = useNavigate();
  const { recipes, searchRecipes, isLoading, getAreas, getCategories } = useRecipes();
  const [areas, setAreas] = useState<RecipeArea[]>([]);
  const [categories, setCategories] = useState<RecipeCategory[]>([]);
  const [filters, setFilters] = useState<{ areas: string[]; categories: string[] }>({
    areas: [],
    categories: [],
  });

  useEffect(() => {
    // Load filter options
    getAreas().then(setAreas);
    getCategories().then(setCategories);
    
    // If no search results and not loading, redirect to home
    if (recipes.length === 0 && !isLoading) {
      // We'll give it a moment before redirecting
      const timer = setTimeout(() => {
        // Only redirect if there are still no recipes
        if (recipes.length === 0) {
          navigate("/");
        }
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [recipes.length, isLoading]);

  const handleSearch = (ingredients: string[]) => {
    searchRecipes(ingredients, filters);
  };

  const handleFilterChange = (newFilters: { areas: string[]; categories: string[] }) => {
    setFilters(newFilters);
    // Re-search with new filters if we have recipes
    if (recipes.length > 0) {
      // We'd need the original ingredients here - in a real app this would come from state
      // For now, we'll just leave this commented out
      // searchRecipes(originalIngredients, newFilters);
    }
  };

  return (
    <div className="min-h-screen py-6">
      <div className="container mx-auto px-4">
        <SearchHeader
          onSearch={handleSearch}
          onFilterChange={handleFilterChange}
          areas={areas}
          categories={categories}
        />
        
        <RecipeResults
          recipes={recipes}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
};

export default SearchResultsPage;
