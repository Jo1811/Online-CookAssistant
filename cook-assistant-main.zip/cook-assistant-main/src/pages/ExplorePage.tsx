
import React, { useState, useEffect } from "react";
import { useRecipes } from "@/contexts/RecipeContext";
import RecipeSlider from "@/components/RecipeSlider";
import { Loader2 } from "lucide-react";
import { RecipeArea, RecipeCategory, Recipe } from "@/contexts/RecipeContext";

const ExplorePage = () => {
  const { getRandomRecipes, getAreas, getCategories, searchByPreference } = useRecipes();
  const [loading, setLoading] = useState(true);
  const [randomRecipes, setRandomRecipes] = useState<Recipe[]>([]);
  const [areas, setAreas] = useState<RecipeArea[]>([]);
  const [categories, setCategories] = useState<RecipeCategory[]>([]);
  const [cuisineRecipes, setCuisineRecipes] = useState<{ [key: string]: Recipe[] }>({});
  const [categoryRecipes, setCategoryRecipes] = useState<{ [key: string]: Recipe[] }>({});

  const featuredCuisines = ["Italian", "American", "Indian", "Chinese", "Mexican"];
  const featuredCategories = ["Breakfast", "Dessert", "Seafood", "Vegetarian"];

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // Get random recipes
        const random = await getRandomRecipes(10);
        setRandomRecipes(random);
        
        // Get all areas and categories
        const allAreas = await getAreas();
        const allCategories = await getCategories();
        setAreas(allAreas);
        setCategories(allCategories);
        
        // Load featured cuisine recipes
        const cuisineData: { [key: string]: Recipe[] } = {};
        for (const cuisine of featuredCuisines) {
          const recipes = await searchByPreference(cuisine);
          if (recipes.length > 0) {
            cuisineData[cuisine] = recipes;
          }
        }
        setCuisineRecipes(cuisineData);
        
        // Load featured category recipes - in a real app would use category API
        // For now, we'll use random recipes as a placeholder
        const categoryData: { [key: string]: Recipe[] } = {};
        for (const category of featuredCategories) {
          const moreRecipes = await getRandomRecipes(8);
          categoryData[category] = moreRecipes;
        }
        setCategoryRecipes(categoryData);
      } catch (error) {
        console.error("Error loading explore data:", error);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="text-center">
          <Loader2 className="h-10 w-10 text-cook-primary animate-spin mx-auto mb-4" />
          <p className="text-gray-500">Loading delicious recipes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-6">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Explore Recipes</h1>
        
        {/* Random Recipes */}
        <RecipeSlider title="Discover New Recipes" recipes={randomRecipes} />
        
        {/* Cuisine Based Sections */}
        <div className="mt-12">
          <h2 className="text-2xl font-semibold mb-6">Explore by Cuisine</h2>
          {Object.entries(cuisineRecipes).map(([cuisine, recipes]) => (
            <RecipeSlider 
              key={cuisine} 
              title={`${cuisine} Cuisine`} 
              recipes={recipes}
              className="mt-8" 
            />
          ))}
        </div>
        
        {/* Category Based Sections */}
        <div className="mt-12">
          <h2 className="text-2xl font-semibold mb-6">Explore by Category</h2>
          {Object.entries(categoryRecipes).map(([category, recipes]) => (
            <RecipeSlider 
              key={category} 
              title={category} 
              recipes={recipes}
              className="mt-8" 
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ExplorePage;
