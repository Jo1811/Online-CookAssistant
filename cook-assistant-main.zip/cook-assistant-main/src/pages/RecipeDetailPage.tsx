
import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useRecipes } from "@/contexts/RecipeContext";
import { Heart, ArrowLeft, Loader2, Youtube } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const RecipeDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getRecipeDetails, addToRecentlyViewed, favorites, addToFavorites, removeFromFavorites } = useRecipes();
  const [recipe, setRecipe] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [youtubeEmbedUrl, setYoutubeEmbedUrl] = useState<string | null>(null);

  const isFavorite = favorites.some(fav => fav.idMeal === id);

  useEffect(() => {
    const loadRecipe = async () => {
      if (!id) return;
      
      setLoading(true);
      try {
        const recipeData = await getRecipeDetails(id);
        if (recipeData) {
          setRecipe(recipeData);
          addToRecentlyViewed(recipeData);
          
          // Extract YouTube video ID and create embed URL
          if (recipeData.strYoutube) {
            const videoIdMatch = recipeData.strYoutube.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
            if (videoIdMatch && videoIdMatch[1]) {
              setYoutubeEmbedUrl(`https://www.youtube.com/embed/${videoIdMatch[1]}`);
            }
          }
        } else {
          toast.error("Recipe not found");
          navigate("/");
        }
      } catch (error) {
        console.error("Error loading recipe:", error);
        toast.error("Failed to load recipe. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    
    loadRecipe();
  }, [id]);

  const toggleFavorite = () => {
    if (!recipe) return;
    
    if (isFavorite) {
      removeFromFavorites(recipe.idMeal);
    } else {
      addToFavorites(recipe);
    }
  };

  const goBack = () => {
    navigate(-1);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="text-center">
          <Loader2 className="h-10 w-10 text-cook-primary animate-spin mx-auto mb-4" />
          <p className="text-gray-500">Loading recipe...</p>
        </div>
      </div>
    );
  }

  if (!recipe) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="text-center">
          <p className="text-gray-500 mb-4">Recipe not found</p>
          <Link to="/">
            <Button>Go to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-6">
      <div className="container mx-auto px-4">
        {/* Navigation */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={goBack}
            className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <ArrowLeft className="h-5 w-5 text-gray-700" />
          </button>
          <h1 className="text-2xl font-bold line-clamp-1">{recipe.strMeal}</h1>
        </div>
        
        {/* Recipe Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Image */}
          <div className="lg:col-span-1">
            <div className="glassmorphism rounded-xl overflow-hidden relative">
              <img 
                src={recipe.strMealThumb} 
                alt={recipe.strMeal}
                className="w-full aspect-square object-cover"
              />
              <button
                onClick={toggleFavorite}
                className="absolute top-4 right-4 p-3 bg-white/80 rounded-full shadow-md hover:bg-white transition-colors"
              >
                <Heart className={cn("h-6 w-6", isFavorite ? "fill-cook-primary text-cook-primary" : "text-gray-600")} />
              </button>
              
              <div className="p-4">
                <div className="flex gap-2 flex-wrap mb-3">
                  <span className="text-sm px-3 py-1 bg-cook-secondary/20 text-cook-secondary rounded-full">
                    {recipe.strCategory}
                  </span>
                  <span className="text-sm px-3 py-1 bg-cook-accent/20 text-cook-accent rounded-full">
                    {recipe.strArea}
                  </span>
                </div>
                
                <h2 className="text-xl font-semibold mb-2">{recipe.strMeal}</h2>
                
                {recipe.strTags && (
                  <div className="flex gap-1 flex-wrap">
                    {recipe.strTags.split(',').map((tag: string) => (
                      <span key={tag} className="text-xs px-2 py-0.5 bg-gray-100 rounded-full text-gray-600">
                        {tag.trim()}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Right Column - Recipe Details */}
          <div className="lg:col-span-2">
            <div className="space-y-8">
              {/* Ingredients */}
              <div className="glassmorphism rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-4">Ingredients</h2>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {recipe.ingredients.map((ingredient: any, index: number) => (
                    <li key={index} className="flex items-start gap-2 py-1.5">
                      <div className="h-2 w-2 bg-cook-primary rounded-full mt-2 flex-shrink-0"></div>
                      <span className="font-medium">{ingredient.measure}</span>
                      <span>{ingredient.name}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* Instructions */}
              <div className="glassmorphism rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-4">Instructions</h2>
                <div className="space-y-4">
                  {recipe.strInstructions.split(/\r?\n/).filter((step: string) => step.trim()).map((step: string, index: number) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-cook-primary text-white flex items-center justify-center">
                        {index + 1}
                      </div>
                      <p className="text-gray-700">{step.trim()}</p>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* YouTube Video */}
              {youtubeEmbedUrl && (
                <div className="glassmorphism rounded-xl p-6">
                  <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                    <Youtube className="h-5 w-5 text-red-600" />
                    Video Tutorial
                  </h2>
                  <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                      width="100%"
                      height="100%"
                      src={youtubeEmbedUrl}
                      title={`${recipe.strMeal} Video Tutorial`}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecipeDetailPage;
