
import React from "react";
import { Link } from "react-router-dom";
import { useRecipes } from "@/contexts/RecipeContext";
import RecipeCard from "@/components/RecipeCard";
import { HeartOff } from "lucide-react";
import { Button } from "@/components/ui/button";

const FavoritesPage = () => {
  const { favorites } = useRecipes();

  return (
    <div className="min-h-screen py-6">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Your Favorite Recipes</h1>
        
        {favorites.length === 0 ? (
          <div className="text-center py-12">
            <HeartOff className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h2 className="text-xl font-medium text-gray-600 mb-4">No favorite recipes yet</h2>
            <p className="text-gray-500 mb-6">
              Start exploring recipes and add them to your favorites
            </p>
            <Link to="/">
              <Button className="bg-cook-primary hover:bg-cook-primary/90">
                Discover Recipes
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {favorites.map((recipe) => (
              <RecipeCard key={recipe.idMeal} recipe={recipe} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FavoritesPage;
