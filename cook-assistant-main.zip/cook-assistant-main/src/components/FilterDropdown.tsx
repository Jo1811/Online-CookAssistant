
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ChevronDown, Filter, Check } from "lucide-react";
import { RecipeArea, RecipeCategory } from "@/contexts/RecipeContext";
import { cn } from "@/lib/utils";

interface FilterDropdownProps {
  areas: RecipeArea[];
  categories: RecipeCategory[];
  onFilterChange: (filters: { areas: string[]; categories: string[] }) => void;
  className?: string;
}

const FilterDropdown: React.FC<FilterDropdownProps> = ({
  areas,
  categories,
  onFilterChange,
  className,
}) => {
  const [selectedAreas, setSelectedAreas] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [open, setOpen] = useState(false);

  const toggleArea = (area: string) => {
    setSelectedAreas(prev =>
      prev.includes(area)
        ? prev.filter(a => a !== area)
        : [...prev, area]
    );
  };

  const toggleCategory = (category: string) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const applyFilters = () => {
    onFilterChange({
      areas: selectedAreas,
      categories: selectedCategories,
    });
    setOpen(false);
  };

  const resetFilters = () => {
    setSelectedAreas([]);
    setSelectedCategories([]);
    onFilterChange({ areas: [], categories: [] });
    setOpen(false);
  };

  const totalFilters = selectedAreas.length + selectedCategories.length;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "flex items-center gap-2 bg-white border-gray-200 hover:bg-gray-50",
            className
          )}
        >
          <Filter className="h-4 w-4" />
          <span>Filters</span>
          {totalFilters > 0 && (
            <span className="inline-flex items-center justify-center w-5 h-5 text-xs font-medium rounded-full bg-cook-primary text-white">
              {totalFilters}
            </span>
          )}
          <ChevronDown className="h-4 w-4 ml-1" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="grid gap-4 p-4">
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Cuisine Type</h4>
            <div className="grid grid-cols-2 gap-2 mt-2 max-h-40 overflow-y-auto">
              {areas.map((area) => (
                <div key={area.strArea} className="flex items-center space-x-2">
                  <Checkbox
                    id={`area-${area.strArea}`}
                    checked={selectedAreas.includes(area.strArea)}
                    onCheckedChange={() => toggleArea(area.strArea)}
                  />
                  <Label
                    htmlFor={`area-${area.strArea}`}
                    className="text-sm cursor-pointer"
                  >
                    {area.strArea}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium text-sm">Categories</h4>
            <div className="grid grid-cols-2 gap-2 mt-2 max-h-40 overflow-y-auto">
              {categories.map((category) => (
                <div key={category.strCategory} className="flex items-center space-x-2">
                  <Checkbox
                    id={`category-${category.strCategory}`}
                    checked={selectedCategories.includes(category.strCategory)}
                    onCheckedChange={() => toggleCategory(category.strCategory)}
                  />
                  <Label
                    htmlFor={`category-${category.strCategory}`}
                    className="text-sm cursor-pointer"
                  >
                    {category.strCategory}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-between pt-2 border-t">
            <Button
              variant="outline"
              size="sm"
              className="text-gray-500"
              onClick={resetFilters}
            >
              Reset
            </Button>
            <Button size="sm" onClick={applyFilters} className="bg-cook-primary hover:bg-cook-primary/90">
              <Check className="mr-2 h-4 w-4" /> Apply
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default FilterDropdown;
