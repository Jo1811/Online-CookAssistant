
import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import SelectedIngredient from "./search/SelectedIngredient";
import IngredientSuggestions from "./search/IngredientSuggestions";
import VoiceInputButton from "./search/VoiceInputButton";
import SearchOptions from "./search/SearchOptions";
import { commonIngredients } from "./search/commonIngredients";

interface SearchBarProps {
  onSearch: (ingredients: string[]) => void;
  className?: string;
  initialIngredients?: string[];
  showOptions?: boolean;
}

const SearchBar: React.FC<SearchBarProps> = ({ 
  onSearch, 
  className, 
  initialIngredients = [], 
  showOptions = false 
}) => {
  const [inputValue, setInputValue] = useState("");
  const [ingredients, setIngredients] = useState<string[]>(initialIngredients);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [requireAllIngredients, setRequireAllIngredients] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Update ingredients when initialIngredients prop changes
  useEffect(() => {
    if (initialIngredients.length > 0) {
      setIngredients(initialIngredients);
    }
  }, [initialIngredients]);

  useEffect(() => {
    if (inputValue.trim().length > 1) {
      const filtered = commonIngredients.filter(
        ingredient => ingredient.toLowerCase().includes(inputValue.toLowerCase())
      );
      setSuggestions(filtered);
    } else {
      setSuggestions([]);
    }
  }, [inputValue]);

  const addIngredient = (ingredient: string) => {
    if (ingredient.trim() && !ingredients.includes(ingredient.trim().toLowerCase())) {
      setIngredients([...ingredients, ingredient.trim().toLowerCase()]);
      setInputValue("");
      setSuggestions([]);
    }
  };

  const removeIngredient = (ingredient: string) => {
    setIngredients(ingredients.filter(i => i !== ingredient));
  };

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && inputValue.trim()) {
      e.preventDefault();
      addIngredient(inputValue);
    } else if (e.key === "Backspace" && inputValue === "" && ingredients.length > 0) {
      removeIngredient(ingredients[ingredients.length - 1]);
    }
  };

  const handleSearch = () => {
    if (ingredients.length === 0) {
      toast.error("Please add at least one ingredient");
      return;
    }
    onSearch(ingredients);
  };

  const handleVoiceInput = (transcript: string) => {
    setInputValue(transcript);
    setTimeout(() => {
      addIngredient(transcript);
    }, 500);
  };

  const toggleRequireAll = () => {
    setRequireAllIngredients(!requireAllIngredients);
  };

  return (
    <div className={cn("w-full", className)}>
      <div className="glassmorphism rounded-xl p-4 shadow-lg">
        <div className="relative">
          <div className="flex flex-wrap gap-2 items-center p-2 min-h-12 border border-gray-300/50 rounded-lg bg-white/70 mb-3">
            {ingredients.map((ingredient) => (
              <SelectedIngredient
                key={ingredient}
                ingredient={ingredient}
                onRemove={removeIngredient}
              />
            ))}
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleInputKeyDown}
              className="flex-grow min-w-20 h-8 bg-transparent outline-none text-sm placeholder:text-gray-400"
              placeholder={ingredients.length > 0 ? "Add more ingredients..." : "Add ingredients..."}
              aria-label="Add ingredients"
            />
          </div>
          
          <IngredientSuggestions 
            suggestions={suggestions} 
            onSelect={addIngredient} 
          />
          
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <VoiceInputButton onTranscript={handleVoiceInput} />
              
              {showOptions && (
                <SearchOptions 
                  requireAllIngredients={requireAllIngredients}
                  onToggleRequireAll={toggleRequireAll}
                />
              )}
            </div>
            
            <Button
              type="button"
              onClick={handleSearch}
              className="cookery-button bg-cook-primary hover:bg-cook-primary/90 text-white"
              disabled={ingredients.length === 0}
            >
              <Search className="h-4 w-4 mr-2" />
              Search Recipes
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchBar;
