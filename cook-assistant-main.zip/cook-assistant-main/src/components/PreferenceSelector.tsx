
import React, { useState } from "react";
import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface PreferenceSelectorProps {
  preferences: string[];
  selectedPreferences: string[];
  onChange: (preferences: string[]) => void;
  className?: string;
}

const PreferenceSelector: React.FC<PreferenceSelectorProps> = ({
  preferences,
  selectedPreferences,
  onChange,
  className,
}) => {
  const togglePreference = (preference: string) => {
    if (selectedPreferences.includes(preference)) {
      onChange(selectedPreferences.filter(p => p !== preference));
    } else {
      onChange([...selectedPreferences, preference]);
    }
  };

  return (
    <div className={cn("space-y-3", className)}>
      <h3 className="text-lg font-medium">Cuisine Preferences</h3>
      <div className="flex flex-wrap gap-2">
        {preferences.map(preference => (
          <button
            key={preference}
            onClick={() => togglePreference(preference)}
            className={cn(
              "flex items-center gap-1 px-3 py-1.5 rounded-full text-sm transition-all",
              selectedPreferences.includes(preference)
                ? "bg-cook-primary text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            )}
          >
            {selectedPreferences.includes(preference) ? (
              <Check className="h-3.5 w-3.5" />
            ) : null}
            <span>{preference}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default PreferenceSelector;
