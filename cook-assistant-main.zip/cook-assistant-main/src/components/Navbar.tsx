
import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { 
  Menu, X, Heart, User, Home, LogOut, ChefHat, ArrowLeft
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

interface NavbarProps {
  className?: string;
}

const Navbar: React.FC<NavbarProps> = ({ className }) => {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const isMobile = useIsMobile();
  const isHomePage = location.pathname === "/";

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    navigate("/");
    closeMobileMenu();
  };

  const goBack = () => {
    navigate(-1);
  };

  return (
    <header className={cn("sticky top-0 z-50 w-full", className)}>
      <div className="glass border-b border-gray-200/50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Back Button (when not on homepage) */}
            {!isHomePage && (
              <button
                onClick={goBack}
                className="mr-2 p-2 rounded-full hover:bg-gray-100/50 text-gray-700"
                aria-label="Go back"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            )}

            {/* Logo */}
            <Link to="/" className="flex items-center gap-2" onClick={closeMobileMenu}>
              <img src="/lovable-uploads/fbb3f56d-2e3a-40bd-be5d-c3f89995de4d.png" alt="Cooking Assistant" className="h-10 w-10" />
              <span className="font-bold text-xl text-cook-dark hidden sm:block">Cooking Assistant</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              <Link 
                to="/" 
                className="text-gray-700 hover:text-cook-primary transition-colors flex items-center gap-1"
              >
                <Home className="h-4 w-4" />
                <span>Home</span>
              </Link>
              
              <Link 
                to="/explore" 
                className="text-gray-700 hover:text-cook-primary transition-colors flex items-center gap-1"
              >
                <ChefHat className="h-4 w-4" />
                <span>Explore</span>
              </Link>
              
              <Link 
                to="/favorites" 
                className="text-gray-700 hover:text-cook-primary transition-colors flex items-center gap-1"
              >
                <Heart className="h-4 w-4" />
                <span>Favorites</span>
              </Link>
            </nav>

            {/* Right Side - Auth/User */}
            <div className="flex items-center gap-3">
              {user ? (
                <div className="hidden md:flex items-center gap-3">
                  <Link 
                    to="/profile" 
                    className="text-gray-700 hover:text-cook-primary transition-colors flex items-center gap-1"
                  >
                    <span className="text-sm font-medium">{user.username}</span>
                    <User className="h-4 w-4" />
                  </Link>
                  <Button 
                    variant="outline"
                    size="sm"
                    onClick={handleLogout}
                    className="text-xs"
                  >
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="hidden md:block">
                  <Link to="/auth">
                    <Button 
                      variant="default" 
                      size="sm"
                      className="bg-cook-primary hover:bg-cook-primary/90 text-white"
                    >
                      Login
                    </Button>
                  </Link>
                </div>
              )}

              {/* Mobile Menu Button */}
              <button 
                className="md:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100/50" 
                onClick={toggleMobileMenu}
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 md:hidden" onClick={closeMobileMenu}>
          <div 
            className="absolute right-0 top-0 h-full w-64 bg-white shadow-xl animate-slide-in-right"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col h-full">
              <div className="p-4 border-b">
                {user ? (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2 mb-2">
                      <User className="h-5 w-5 text-cook-primary" />
                      <span className="font-medium">{user.username}</span>
                    </div>
                    <Link 
                      to="/profile" 
                      className="text-sm text-gray-600 hover:text-cook-primary transition-colors py-1"
                      onClick={closeMobileMenu}
                    >
                      View Profile
                    </Link>
                    <button 
                      className="text-sm text-red-500 hover:text-red-600 transition-colors py-1 text-left flex items-center gap-1"
                      onClick={handleLogout}
                    >
                      <LogOut className="h-4 w-4" />
                      <span>Logout</span>
                    </button>
                  </div>
                ) : (
                  <Link 
                    to="/auth" 
                    className="block w-full"
                    onClick={closeMobileMenu}
                  >
                    <Button 
                      variant="default" 
                      className="w-full bg-cook-primary hover:bg-cook-primary/90 text-white"
                    >
                      Login
                    </Button>
                  </Link>
                )}
              </div>
              
              <nav className="p-4 flex-1">
                <ul className="space-y-2">
                  <li>
                    <Link 
                      to="/" 
                      className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-md text-gray-700"
                      onClick={closeMobileMenu}
                    >
                      <Home className="h-5 w-5" />
                      <span>Home</span>
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/explore" 
                      className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-md text-gray-700"
                      onClick={closeMobileMenu}
                    >
                      <ChefHat className="h-5 w-5" />
                      <span>Explore</span>
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/favorites" 
                      className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-md text-gray-700"
                      onClick={closeMobileMenu}
                    >
                      <Heart className="h-5 w-5" />
                      <span>Favorites</span>
                    </Link>
                  </li>
                </ul>
              </nav>
              
              <div className="p-4 text-center text-sm text-gray-500 border-t">
                <p>© 2023 Cooking Assistant</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
