
import React from "react";
import RecipeCard from "@/components/RecipeCard";
import { Loader2 } from "lucide-react";

interface RecipeResultsProps {
  recipes: any[];
  isLoading: boolean;
}

const RecipeResults: React.FC<RecipeResultsProps> = ({ recipes, isLoading }) => {
  return (
    <div className="mt-8">
      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="text-center">
            <Loader2 className="h-8 w-8 text-cook-primary animate-spin mx-auto mb-4" />
            <p className="text-gray-500">Searching for recipes...</p>
          </div>
        </div>
      ) : recipes.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 mb-4">No recipes found. Try different ingredients or filters.</p>
        </div>
      ) : (
        <>
          <p className="text-gray-600 mb-4">Found {recipes.length} recipes</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {recipes.map((recipe) => (
              <RecipeCard key={recipe.idMeal} recipe={recipe} />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default RecipeResults;
