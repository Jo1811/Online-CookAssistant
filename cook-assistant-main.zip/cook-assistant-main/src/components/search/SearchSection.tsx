
import React from "react";
import SearchBar from "@/components/SearchBar";
import FilterDropdown from "@/components/FilterDropdown";
import { RecipeArea, RecipeCategory } from "@/contexts/RecipeContext";
import { cn } from "@/lib/utils";

interface SearchSectionProps {
  onSearch: (ingredients: string[]) => void;
  onFilterChange: (filters: { areas: string[]; categories: string[] }) => void;
  areas: RecipeArea[];
  categories: RecipeCategory[];
  className?: string;
  layout?: "horizontal" | "vertical";
}

const SearchSection: React.FC<SearchSectionProps> = ({
  onSearch,
  onFilterChange,
  areas,
  categories,
  className,
  layout = "horizontal",
}) => {
  return (
    <div className={cn("w-full", className)}>
      {layout === "horizontal" ? (
        <div className="flex justify-center">
          <div className="w-full max-w-2xl">
            <SearchBar onSearch={onSearch} />
            <div className="mt-4 flex justify-center">
              <FilterDropdown
                areas={areas}
                categories={categories}
                onFilterChange={onFilterChange}
              />
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col md:flex-row gap-4 items-start">
          <div className="w-full md:flex-1">
            <SearchBar onSearch={onSearch} />
          </div>
          <div className="w-full md:w-auto">
            <FilterDropdown
              areas={areas}
              categories={categories}
              onFilterChange={onFilterChange}
              className="w-full md:w-auto"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchSection;
