
import React from "react";
import { X } from "lucide-react";

interface SelectedIngredientProps {
  ingredient: string;
  onRemove: (ingredient: string) => void;
}

const SelectedIngredient: React.FC<SelectedIngredientProps> = ({
  ingredient,
  onRemove,
}) => {
  return (
    <div className="flex items-center gap-1 px-3 py-1 bg-cook-primary/20 text-cook-primary rounded-full text-sm">
      <span>{ingredient}</span>
      <button
        type="button"
        onClick={() => onRemove(ingredient)}
        className="text-cook-primary hover:text-cook-primary/80"
      >
        <X className="h-3 w-3" />
      </button>
    </div>
  );
};

export default SelectedIngredient;
