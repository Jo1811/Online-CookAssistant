
export const commonIngredients = [
  "chicken", "beef", "pork", "rice", "pasta", "tomato", "onion", "garlic", 
  "potato", "carrot", "bell pepper", "cheese", "egg", "milk", "butter", 
  "olive oil", "flour", "sugar", "salt", "lemon"
];
