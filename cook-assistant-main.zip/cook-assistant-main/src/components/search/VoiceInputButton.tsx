
import React, { useState, useEffect } from "react";
import { Mic } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { SpeechRecognition } from "@/types/speech-recognition";

interface VoiceInputButtonProps {
  onTranscript: (transcript: string) => void;
  className?: string;
}

// We don't need to redeclare the global interface since it's already defined in speech-recognition.d.ts

const VoiceInputButton: React.FC<VoiceInputButtonProps> = ({
  onTranscript,
  className,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    const speechRecognitionSupported = 
      'SpeechRecognition' in window || 
      'webkitSpeechRecognition' in window;
      
    setIsSupported(speechRecognitionSupported);
  }, []);

  const toggleListening = () => {
    if (!isSupported) {
      toast.error("Speech recognition is not supported in your browser");
      return;
    }

    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const startListening = () => {
    setIsListening(true);
    
    const SpeechRecognitionConstructor = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognitionConstructor();
    
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      onTranscript(transcript);
      setIsListening(false);
    };
    
    recognition.onerror = (event) => {
      console.error('Speech recognition error', event.error);
      toast.error(`Speech recognition error: ${event.error}`);
      setIsListening(false);
    };
    
    recognition.onend = () => {
      setIsListening(false);
    };
    
    try {
      recognition.start();
    } catch (error) {
      console.error('Speech recognition start error:', error);
      toast.error("Failed to start speech recognition");
      setIsListening(false);
    }
  };

  const stopListening = () => {
    setIsListening(false);
    // Speech recognition will auto-stop once it gets a result
  };

  if (!isSupported) {
    return null;
  }

  return (
    <Button
      type="button"
      variant="outline"
      size="icon"
      className={cn(
        "rounded-full w-8 h-8 border border-gray-300/50 bg-white/70", 
        isListening && "text-cook-primary border-cook-primary/50 bg-cook-primary/10",
        className
      )}
      onClick={toggleListening}
      title="Use voice input"
      aria-label="Use voice input"
    >
      <Mic className="h-4 w-4" />
    </Button>
  );
};

export default VoiceInputButton;
