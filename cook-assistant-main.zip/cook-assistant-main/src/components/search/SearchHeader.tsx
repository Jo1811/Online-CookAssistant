
import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import SearchBar from "@/components/SearchBar";
import FilterDropdown from "@/components/FilterDropdown";
import NutritionFilter from "@/components/NutritionFilter";
import { RecipeArea, RecipeCategory } from "@/contexts/RecipeContext";

interface SearchHeaderProps {
  onSearch: (ingredients: string[]) => void;
  onFilterChange: (filters: { areas: string[]; categories: string[]; nutrition?: { fiber?: boolean; protein?: boolean; carbs?: boolean } }) => void;
  areas: RecipeArea[];
  categories: RecipeCategory[];
}

const SearchHeader: React.FC<SearchHeaderProps> = ({ 
  onSearch, 
  onFilterChange,
  areas,
  categories
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);
  const [filters, setFilters] = useState<{
    areas: string[];
    categories: string[];
    nutrition: {
      fiber: boolean;
      protein: boolean;
      carbs: boolean;
    };
  }>({
    areas: [],
    categories: [],
    nutrition: {
      fiber: false,
      protein: false,
      carbs: false
    }
  });

  // Parse URL search params to restore search state
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const ingredients = searchParams.get("ingredients");
    
    if (ingredients) {
      const ingredientsList = ingredients.split(",");
      setSelectedIngredients(ingredientsList);
      onSearch(ingredientsList);
    }
  }, [location.search]);

  const handleSearch = (ingredients: string[]) => {
    if (ingredients.length === 0) return;
    
    setSelectedIngredients(ingredients);
    
    // Update URL search parameters
    const searchParams = new URLSearchParams();
    searchParams.set("ingredients", ingredients.join(","));
    navigate(`${location.pathname}?${searchParams.toString()}`);
    
    onSearch(ingredients);
  };

  const handleFilterChange = (newFilters: { areas: string[]; categories: string[] }) => {
    const updatedFilters = {
      ...filters,
      ...newFilters
    };
    
    setFilters(updatedFilters);
    onFilterChange(updatedFilters);
  };

  const handleNutritionChange = (nutrition: { fiber: boolean; protein: boolean; carbs: boolean }) => {
    const updatedFilters = {
      ...filters,
      nutrition
    };
    
    setFilters(updatedFilters);
    onFilterChange(updatedFilters);
  };

  return (
    <div className="mb-8">
      <h1 className="text-2xl font-bold mb-6">Find Recipes with Your Ingredients</h1>
      
      <div className="glassmorphism rounded-xl p-6 shadow-md">
        <SearchBar 
          initialIngredients={selectedIngredients}
          onSearch={handleSearch}
          showOptions={true}
        />
        
        <div className="flex flex-wrap items-center gap-2 mt-4">
          <FilterDropdown
            areas={areas}
            categories={categories}
            onFilterChange={handleFilterChange}
          />
          
          <NutritionFilter
            selectedNutrition={filters.nutrition}
            onChange={handleNutritionChange}
          />
        </div>
      </div>
    </div>
  );
};

export default SearchHeader;
