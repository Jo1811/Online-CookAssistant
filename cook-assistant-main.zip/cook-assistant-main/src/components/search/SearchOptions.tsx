
import React from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface SearchOptionsProps {
  requireAllIngredients: boolean;
  onToggleRequireAll: () => void;
}

const SearchOptions: React.FC<SearchOptionsProps> = ({
  requireAllIngredients,
  onToggleRequireAll,
}) => {
  return (
    <button
      type="button"
      onClick={onToggleRequireAll}
      className={cn(
        "flex items-center gap-1 text-sm px-3 py-1 rounded-full transition-colors",
        requireAllIngredients 
          ? "bg-cook-secondary/20 text-cook-secondary" 
          : "bg-gray-200/50 text-gray-600"
      )}
    >
      <Check className="h-4 w-4" />
      <span>Require all</span>
    </button>
  );
};

export default SearchOptions;
