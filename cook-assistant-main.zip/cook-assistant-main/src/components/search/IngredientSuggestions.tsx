
import React from "react";

interface IngredientSuggestionsProps {
  suggestions: string[];
  onSelect: (ingredient: string) => void;
}

const IngredientSuggestions: React.FC<IngredientSuggestionsProps> = ({
  suggestions,
  onSelect,
}) => {
  if (suggestions.length === 0) return null;

  return (
    <div className="absolute z-10 left-0 right-0 bg-white shadow-lg rounded-lg mt-1 py-2 max-h-60 overflow-y-auto">
      {suggestions.map((suggestion) => (
        <button
          key={suggestion}
          className="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm"
          onClick={() => onSelect(suggestion)}
        >
          {suggestion}
        </button>
      ))}
    </div>
  );
};

export default IngredientSuggestions;
