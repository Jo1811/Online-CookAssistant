
import React from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ChevronDown, Dumbbell } from "lucide-react";
import { cn } from "@/lib/utils";

interface NutritionFilterProps {
  selectedNutrition: {
    fiber: boolean;
    protein: boolean;
    carbs: boolean;
  };
  onChange: (nutrition: { fiber: boolean; protein: boolean; carbs: boolean }) => void;
  className?: string;
}

const NutritionFilter: React.FC<NutritionFilterProps> = ({
  selectedNutrition,
  onChange,
  className,
}) => {
  const toggleNutrition = (type: keyof typeof selectedNutrition) => {
    onChange({
      ...selectedNutrition,
      [type]: !selectedNutrition[type],
    });
  };

  const totalSelected = Object.values(selectedNutrition).filter(Boolean).length;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "flex items-center gap-2 bg-white border-gray-200 hover:bg-gray-50",
            className
          )}
        >
          <Dumbbell className="h-4 w-4" />
          <span>Nutrition</span>
          {totalSelected > 0 && (
            <span className="inline-flex items-center justify-center w-5 h-5 text-xs font-medium rounded-full bg-cook-primary text-white">
              {totalSelected}
            </span>
          )}
          <ChevronDown className="h-4 w-4 ml-1" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-4" align="end">
        <div className="space-y-4">
          <h4 className="font-medium text-sm">Nutrition Filters</h4>
          
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="filter-protein"
                checked={selectedNutrition.protein}
                onCheckedChange={() => toggleNutrition("protein")}
              />
              <Label htmlFor="filter-protein" className="text-sm cursor-pointer">
                High Protein
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="filter-fiber"
                checked={selectedNutrition.fiber}
                onCheckedChange={() => toggleNutrition("fiber")}
              />
              <Label htmlFor="filter-fiber" className="text-sm cursor-pointer">
                High Fiber
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="filter-carbs"
                checked={selectedNutrition.carbs}
                onCheckedChange={() => toggleNutrition("carbs")}
              />
              <Label htmlFor="filter-carbs" className="text-sm cursor-pointer">
                High Carbs
              </Label>
            </div>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default NutritionFilter;
