
import React, { useRef, useEffect, useState } from "react";
import { Recipe } from "@/contexts/RecipeContext";
import RecipeCard from "./RecipeCard";
import { cn } from "@/lib/utils";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface RecipeSliderProps {
  title: string;
  recipes: Recipe[];
  className?: string;
  maxCards?: number;
}

const RecipeSlider: React.FC<RecipeSliderProps> = ({ 
  title, 
  recipes, 
  className, 
  maxCards = 4 
}) => {
  const sliderRef = useRef<HTMLDivElement>(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const isMobile = useIsMobile();

  const scroll = (direction: "left" | "right") => {
    if (!sliderRef.current) return;
    
    // Increase scroll amount for larger cards
    const scrollAmount = isMobile ? 380 : 700;
    const currentScroll = sliderRef.current.scrollLeft;
    
    sliderRef.current.scrollTo({
      left: direction === "left" ? currentScroll - scrollAmount : currentScroll + scrollAmount,
      behavior: "smooth"
    });
  };

  const checkScrollPosition = () => {
    if (!sliderRef.current) return;
    
    const { scrollLeft, scrollWidth, clientWidth } = sliderRef.current;
    setShowLeftArrow(scrollLeft > 10);
    setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 10);
  };

  useEffect(() => {
    const slider = sliderRef.current;
    if (slider) {
      slider.addEventListener("scroll", checkScrollPosition);
      checkScrollPosition();
      
      return () => {
        slider.removeEventListener("scroll", checkScrollPosition);
      };
    }
  }, [recipes]);

  useEffect(() => {
    checkScrollPosition();
    
    // Add window resize listener to check scroll position
    window.addEventListener('resize', checkScrollPosition);
    return () => {
      window.removeEventListener('resize', checkScrollPosition);
    };
  }, [recipes]);

  if (recipes.length === 0) {
    return null;
  }

  // Display only the first maxCards recipes in popular recipes section
  const displayedRecipes = recipes.slice(0, maxCards);

  return (
    <div className={cn("relative py-10", className)}>
      <h2 className="text-2xl font-semibold mb-10">{title}</h2>
      
      <div className="relative">
        {showLeftArrow && (
          <button 
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 rounded-full p-4 shadow-md hover:bg-white transition-colors"
            onClick={() => scroll("left")}
            aria-label="Scroll left"
          >
            <ChevronLeft className="h-8 w-8" />
          </button>
        )}
        
        {showRightArrow && (
          <button 
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 rounded-full p-4 shadow-md hover:bg-white transition-colors"
            onClick={() => scroll("right")}
            aria-label="Scroll right"
          >
            <ChevronRight className="h-8 w-8" />
          </button>
        )}
        
        <div 
          ref={sliderRef}
          className="flex gap-10 overflow-x-auto pb-8 no-scrollbar recipe-slider snap-x snap-mandatory"
        >
          {displayedRecipes.map(recipe => (
            <div key={recipe.idMeal} className="snap-start">
              <RecipeCard recipe={recipe} variant="slider" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RecipeSlider;
