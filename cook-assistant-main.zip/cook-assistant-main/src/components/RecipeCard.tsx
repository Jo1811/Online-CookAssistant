
import React from "react";
import { Link } from "react-router-dom";
import { Recipe } from "@/contexts/RecipeContext";
import { Heart } from "lucide-react";
import { useRecipes } from "@/contexts/RecipeContext";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

interface RecipeCardProps {
  recipe: Recipe;
  variant?: "standard" | "slider" | "compact";
  className?: string;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, variant = "standard", className }) => {
  const { favorites, addToFavorites, removeFromFavorites } = useRecipes();
  const isFavorite = favorites.some(fav => fav.idMeal === recipe.idMeal);
  const isMobile = useIsMobile();

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isFavorite) {
      removeFromFavorites(recipe.idMeal);
    } else {
      addToFavorites(recipe);
    }
  };

  if (variant === "compact") {
    return (
      <Link 
        to={`/recipe/${recipe.idMeal}`}
        className={cn(
          "group cookery-card flex items-center h-40 bg-white/90 shadow-sm hover:shadow-md transition-all",
          className
        )}
      >
        <div className="w-40 h-40 flex-shrink-0">
          <img 
            src={recipe.strMealThumb} 
            alt={recipe.strMeal} 
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>
        <div className="flex-grow p-4">
          <div className="flex justify-between">
            <h3 className="font-medium text-lg line-clamp-1">{recipe.strMeal}</h3>
            <button
              onClick={toggleFavorite}
              className="text-cook-primary hover:text-red-500 transition-colors"
            >
              <Heart className={cn("w-6 h-6", isFavorite ? "fill-current" : "")} />
            </button>
          </div>
          <div className="flex items-center mt-2">
            <span className="text-base text-gray-500">{recipe.strArea}</span>
            {recipe.matchedIngredients !== undefined && (
              <span className="ml-auto text-sm text-cook-secondary font-medium">
                {recipe.matchedIngredients} matched
              </span>
            )}
          </div>
        </div>
      </Link>
    );
  }

  if (variant === "slider") {
    return (
      <Link 
        to={`/recipe/${recipe.idMeal}`}
        className={cn(
          "cookery-card bg-white/80 flex-shrink-0 w-[360px] h-[480px] md:w-[420px] md:h-[560px] lg:w-[480px] lg:h-[640px] group relative overflow-hidden",
          className
        )}
      >
        <img 
          src={recipe.strMealThumb} 
          alt={recipe.strMeal} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent p-6 flex flex-col justify-end">
          <h3 className="text-white font-semibold line-clamp-2 text-2xl md:text-3xl lg:text-4xl mb-3">{recipe.strMeal}</h3>
          <div className="flex justify-between items-center">
            <span className="text-white/90 text-lg md:text-xl">{recipe.strArea}</span>
            <button
              onClick={toggleFavorite}
              className="text-white hover:text-cook-primary transition-colors z-10"
            >
              <Heart className={cn("w-7 h-7 md:w-8 md:h-8", isFavorite ? "fill-current text-cook-primary" : "")} />
            </button>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link 
      to={`/recipe/${recipe.idMeal}`}
      className={cn(
        "cookery-card bg-white/90 flex flex-col overflow-hidden group",
        className
      )}
    >
      <div className="relative h-80 md:h-96 lg:h-[28rem] overflow-hidden">
        <img 
          src={recipe.strMealThumb} 
          alt={recipe.strMeal} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <button
          onClick={toggleFavorite}
          className="absolute top-4 right-4 p-2 bg-white/80 rounded-full shadow-md hover:bg-white transition-colors z-10"
        >
          <Heart className={cn("w-7 h-7", isFavorite ? "fill-current text-cook-primary" : "text-gray-600")} />
        </button>
      </div>
      <div className="p-6">
        <h3 className="font-medium text-xl md:text-2xl lg:text-3xl mb-4 line-clamp-1">{recipe.strMeal}</h3>
        <div className="flex justify-between items-center">
          <div className="flex flex-wrap gap-2">
            <span className="text-base md:text-lg px-3 py-1 bg-cook-muted rounded-full">{recipe.strArea}</span>
            <span className="text-base md:text-lg px-3 py-1 bg-cook-muted rounded-full">{recipe.strCategory}</span>
          </div>
        </div>
        {recipe.matchedIngredients !== undefined && recipe.missingIngredients !== undefined && (
          <div className="mt-5 flex items-center text-base md:text-lg">
            <span className="text-cook-secondary">
              {recipe.matchedIngredients} ingredients matched
            </span>
            <span className="mx-2">•</span>
            <span className="text-gray-500">
              {recipe.missingIngredients} missing
            </span>
          </div>
        )}
      </div>
    </Link>
  );
};

export default RecipeCard;
