
import React from "react";
import SearchSection from "@/components/search/SearchSection";
import { RecipeArea, RecipeCategory } from "@/contexts/RecipeContext";

interface HeroSectionProps {
  onSearch: (ingredients: string[]) => void;
  onFilterChange: (filters: { areas: string[]; categories: string[] }) => void;
  areas: RecipeArea[];
  categories: RecipeCategory[];
}

const HeroSection: React.FC<HeroSectionProps> = ({
  onSearch,
  onFilterChange,
  areas,
  categories,
}) => {
  return (
    <section className="relative py-16 overflow-hidden">
      <div className="absolute inset-0 bg-food-pattern bg-cover bg-center opacity-15 -z-10"></div>
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-8 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-cook-dark">
            Cook with what you have
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Enter your ingredients and discover delicious recipes you can make right now
          </p>
          
          <SearchSection
            onSearch={onSearch}
            onFilterChange={onFilterChange}
            areas={areas}
            categories={categories}
            layout="horizontal"
          />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
