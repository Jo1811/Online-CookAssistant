
import React from "react";
import RecipeSlider from "@/components/RecipeSlider";
import RecipeCard from "@/components/RecipeCard";

interface RecipeSectionProps {
  popularRecipes: any[];
  preferenceRecipes: { [key: string]: any[] };
}

const RecipeSection: React.FC<RecipeSectionProps> = ({
  popularRecipes,
  preferenceRecipes,
}) => {
  // Function to get the first three preference recipes for grid display
  const getTopPreferences = () => {
    const entries = Object.entries(preferenceRecipes);
    return entries.slice(0, 3); // Show 3 preferences in grid layout
  };

  // Get the remaining preferences for the sliders
  const getSliderPreferences = () => {
    const entries = Object.entries(preferenceRecipes);
    return entries.slice(3);
  };

  const topPreferences = getTopPreferences();
  const sliderPreferences = getSliderPreferences();

  return (
    <section className="py-16 bg-gray-50/50">
      <div className="container mx-auto px-4">
        {/* Popular Recipes Slider */}
        <RecipeSlider 
          title="Popular Recipes" 
          recipes={popularRecipes} 
          maxCards={4} // Limit to 4 cards in the slider
        />
        
        {/* Top User Preferences as Grid Layout */}
        {topPreferences.length > 0 && (
          <div className="mt-20 space-y-20">
            {topPreferences.map(([preference, recipes]) => (
              <div key={preference}>
                <h2 className="text-2xl font-semibold mb-10">{preference} Favorites</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
                  {recipes.slice(0, 8).map((recipe, index) => (
                    <RecipeCard 
                      key={recipe.idMeal} 
                      recipe={recipe} 
                      className={index >= 4 ? "hidden lg:block" : ""} 
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
        
        {/* Remaining Preference Based Sections as Sliders */}
        {sliderPreferences.map(([preference, recipes]) => (
          <RecipeSlider 
            key={preference} 
            title={`${preference} Favorites`} 
            recipes={recipes}
            className="mt-20"
            maxCards={4} // Limit to 4 cards in the slider
          />
        ))}
      </div>
    </section>
  );
};

export default RecipeSection;
