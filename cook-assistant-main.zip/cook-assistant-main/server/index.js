
const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
const app = express();
app.use(cors());
app.use(express.json());

// Firebase Admin Initialization
const serviceAccount = require('./firebaseConfig.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

// User Authentication Routes
app.post('/register', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await admin.auth().createUser({ email, password });
    res.status(201).send({ uid: user.uid });
  } catch (error) {
    res.status(400).send({ error: error.message });
  }
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await admin.auth().getUserByEmail(email);
    res.status(200).send({ uid: user.uid });
  } catch (error) {
    res.status(400).send({ error: 'Invalid credentials' });
  }
});

// Favorites Management
app.post('/favorites', async (req, res) => {
  const { uid, recipe } = req.body;
  try {
    await db.collection('favorites').add({ uid, recipe });
    res.status(200).send({ message: 'Favorite added' });
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

app.get('/favorites/:uid', async (req, res) => {
  const { uid } = req.params;
  try {
    const snapshot = await db.collection('favorites').where('uid', '==', uid).get();
    const favorites = snapshot.docs.map(doc => doc.data().recipe);
    res.status(200).send(favorites);
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

app.listen(5000, () => console.log('Server running on port 5000'));
